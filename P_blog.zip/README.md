# php_simple_blog
this is a simple php blog.

### Usage

```sh
1) create MySQL database [name="Pblog"]

2) import "Pblog.sql" file
```

### Config (php.ini)

```sh
1) open php.ini file
2) if you want to make changes than PROD_MOD = false otherwise PROD_MOD = true
3) enter MySQL Host, Username, Password (if you have any) and DB name (specify database name).
```

### Thank you!
