<!-- jQuery -->
<script src="assets/jquery/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="assets/bootstrap/js/bootstrap.js"></script>
<!-- JS -->
<script src="js/main.js"></script>

</body>

</html>